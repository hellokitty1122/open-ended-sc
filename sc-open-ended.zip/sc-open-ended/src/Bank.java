import java.util.HashMap;

public class Bank {
    private final HashMap<String, Customer> customers = new HashMap<>();

    public Bank() { seedData(); }

    private void seedData() {
        Customer AMINA = new Customer("AB01", "AMINA", "1234");
        AMINA.addAccount(new SavingsAccount("SAV100", "AB01", 1000, 100));
        AMINA.addAccount(new CheckingAccount("CHK100", "AB01", 500, 200));
        customers.put(AMINA.getCustomerId(), AMINA);

        Customer AISHA = new Customer("AB02", "AISHA", "4321");
        AISHA.addAccount(new SavingsAccount("SAV200", "AB02", 800, 50));
        customers.put(AISHA.getCustomerId(), AISHA);
    }

    public Customer getCustomer(String id) {
        return customers.get(id);
    }
}
