import java.util.Scanner;

public class ATM {
    private final Bank bank;
    private final Scanner input = new Scanner(System.in);

    public ATM(Bank bank) {
        this.bank = bank;
    }

    public void start() {
        System.out.println("Welcome to the ATM System");
        while (true) {
            System.out.print("Enter Customer ID (or 'exit'): ");
            String id = input.nextLine();
            if (id.equalsIgnoreCase("exit")) break;

            Customer c = bank.getCustomer(id);
            if (c == null) {
                System.out.println("Customer not found.");
                continue;
            }

            System.out.print("Enter PIN: ");
            String pin = input.nextLine();
            if (!c.verifyPin(pin)) {
                System.out.println("Incorrect PIN.");
                if (c.isBlocked()) System.out.println("Account is blocked due to multiple failures.");
                continue;
            }

            handleAccounts(c);
        }
    }

    private void handleAccounts(Customer c) {
        while (true) {
            System.out.println("\\nAccounts for " + c.getName());
            for (int i = 0; i < c.getAccounts().size(); i++) {
                System.out.printf("%d) %s - Balance: %.2f%n", i + 1, c.getAccounts().get(i).getAccountNumber(),
                        c.getAccounts().get(i).getBalance());
            }
            System.out.println("0) Logout");
            int choice = Integer.parseInt(input.nextLine());
            if (choice == 0) break;
            if (choice < 1 || choice > c.getAccounts().size()) continue;
            BankAccount acc = c.getAccounts().get(choice - 1);
            accountMenu(acc);
        }
    }

    private void accountMenu(BankAccount acc) {
        while (true) {
            System.out.println("\\n1) Check Balance\\n2) Deposit\\n3) Withdraw\\n4) Transactions\\n0) Back");
            String choice = input.nextLine();
            try {
                switch (choice) {
                    case "1":
                        System.out.println("Balance: " + acc.getBalance());
                        break;
                    case "2":
                        System.out.print("Enter amount: ");
                        acc.deposit(Double.parseDouble(input.nextLine()));
                        System.out.println("Deposit successful.");
                        break;
                    case "3":
                        System.out.print("Enter amount: ");
                        acc.withdraw(Double.parseDouble(input.nextLine()));
                        System.out.println("Withdrawal successful.");
                        break;
                    case "4":
                        for (Transaction t : acc.getTransactions())
                            System.out.println(t);
                        break;
                    case "0":
                        return;
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}
