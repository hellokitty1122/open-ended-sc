import java.util.ArrayList;

public class Customer {
    private final String customerId;
    private final String name;
    private final String pin;
    private boolean blocked = false;
    private int failedAttempts = 0;
    private final ArrayList<BankAccount> accounts = new ArrayList<>();

    public Customer(String customerId, String name, String pin) {
        this.customerId = customerId;
        this.name = name;
        this.pin = pin;
    }

    public String getCustomerId() { return customerId; }
    public String getName() { return name; }
    public boolean isBlocked() { return blocked; }

    public void addAccount(BankAccount acc) { accounts.add(acc); }
    public ArrayList<BankAccount> getAccounts() { return accounts; }

    public boolean verifyPin(String input) {
        if (blocked) return false;
        if (pin.equals(input)) {
            failedAttempts = 0;
            return true;
        } else {
            failedAttempts++;
            if (failedAttempts >= 3) blocked = true;
            return false;
        }
    }
}
