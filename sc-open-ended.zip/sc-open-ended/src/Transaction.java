import java.time.LocalDateTime;
import java.util.UUID;

public class Transaction {
    private final String transactionId;
    private final TransactionType type;
    private final double amount;
    private final LocalDateTime timestamp;
    private final String fromAccount;
    private final String toAccount;
    private final TransactionStatus status;

    public Transaction(TransactionType type, double amount, String fromAccount, String toAccount, TransactionStatus status) {
        this.transactionId = UUID.randomUUID().toString();
        this.type = type;
        this.amount = amount;
        this.timestamp = LocalDateTime.now();
        this.fromAccount = fromAccount;
        this.toAccount = toAccount;
        this.status = status;
    }

    @Override
    public String toString() {
        return String.format("[%s] %s | %.2f | %s | %s",
                timestamp, transactionId, amount, type, status);
    }
}
