public class SavingsAccount extends BankAccount {
    private final double minimumBalance;

    public SavingsAccount(String accountNumber, String customerId, double balance, double minimumBalance) {
        super(accountNumber, customerId, balance);
        this.minimumBalance = minimumBalance;
    }

    @Override
    public void deposit(double amount) throws AccountBlockedException {
        if (status != AccountStatus.ACTIVE)
            throw new AccountBlockedException("Account is blocked");
        balance += amount;
        addTransaction(new Transaction(TransactionType.DEPOSIT, amount, null, accountNumber, TransactionStatus.SUCCESS));
    }

    @Override
    public void withdraw(double amount) throws InsufficientFundsException, AccountBlockedException {
        if (status != AccountStatus.ACTIVE)
            throw new AccountBlockedException("Account is blocked");
        if (balance - amount < minimumBalance)
            throw new InsufficientFundsException("Withdrawal would breach minimum balance");
        balance -= amount;
        addTransaction(new Transaction(TransactionType.WITHDRAWAL, amount, accountNumber, null, TransactionStatus.SUCCESS));
    }
}
