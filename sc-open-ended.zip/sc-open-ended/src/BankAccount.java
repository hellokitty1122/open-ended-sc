import java.util.ArrayList;

public abstract class BankAccount {
    protected final String accountNumber;
    protected double balance;
    protected final String customerId;
    protected AccountStatus status;
    protected final ArrayList<Transaction> transactions = new ArrayList<>();

    public BankAccount(String accountNumber, String customerId, double balance) {
        this.accountNumber = accountNumber;
        this.customerId = customerId;
        this.balance = balance;
        this.status = AccountStatus.ACTIVE;
    }

    public String getAccountNumber() { return accountNumber; }
    public double getBalance() { return balance; }

    public abstract void deposit(double amount) throws AccountBlockedException;
    public abstract void withdraw(double amount) throws InsufficientFundsException, AccountBlockedException;

    public ArrayList<Transaction> getTransactions() { return transactions; }

    protected void addTransaction(Transaction t) { transactions.add(t); }
}
