public class CheckingAccount extends BankAccount {
    private final double overdraftLimit;

    public CheckingAccount(String accountNumber, String customerId, double balance, double overdraftLimit) {
        super(accountNumber, customerId, balance);
        this.overdraftLimit = overdraftLimit;
    }

    @Override
    public void deposit(double amount) throws AccountBlockedException {
        if (status != AccountStatus.ACTIVE)
            throw new AccountBlockedException("Account is blocked");
        balance += amount;
        addTransaction(new Transaction(TransactionType.DEPOSIT, amount, null, accountNumber, TransactionStatus.SUCCESS));
    }

    @Override
    public void withdraw(double amount) throws InsufficientFundsException, AccountBlockedException {
        if (status != AccountStatus.ACTIVE)
            throw new AccountBlockedException("Account is blocked");
        if (balance - amount < -overdraftLimit)
            throw new InsufficientFundsException("Exceeds overdraft limit");
        balance -= amount;
        addTransaction(new Transaction(TransactionType.WITHDRAWAL, amount, accountNumber, null, TransactionStatus.SUCCESS));
    }
}
