import java.util.*;

/**
 * Central repository and operations for customers and accounts.
 */
public class Bank {
    private final Map<String, Customer> customers = new HashMap<>();
    private final Map<String, BankAccount> accounts = new HashMap<>();

    public Bank() {
        initSampleData();
    }

    private void initSampleData() {
        Customer c1 = new Customer("AB01", "AMINA", "1234");
        SavingsAccount s1 = new SavingsAccount("SAV100", c1.getCustomerId(), 1000.0, 100.0);
        CheckingAccount ch1 = new CheckingAccount("CHK100", c1.getCustomerId(), 500.0, 200.0);
        c1.addAccount(s1); c1.addAccount(ch1);
        registerCustomer(c1);
        addAccount(s1); addAccount(ch1);

        Customer c2 = new Customer("AB02", "AISHA", "4321");
        SavingsAccount s2 = new SavingsAccount("SAV200", c2.getCustomerId(), 800.0, 50.0);
        c2.addAccount(s2);
        registerCustomer(c2);
        addAccount(s2);
    }

    public void registerCustomer(Customer c) {
        customers.put(c.getCustomerId(), c);
    }

    public Customer getCustomerById(String id) { return customers.get(id); }

    public void addAccount(BankAccount acc) { accounts.put(acc.getAccountNumber(), acc); }

    public BankAccount getAccountByNumber(String accNo) { return accounts.get(accNo); }

    public Collection<Customer> getAllCustomers() { return customers.values(); }

    public Collection<BankAccount> getAllAccounts() { return accounts.values(); }

    /**
     * Create a new Savings or Checking account for existing customer.
     */
    public void createAccountForCustomer(String customerId, String accNumber, String type, double initialBalance, double extra) throws InvalidAccountException {
        Customer c = getCustomerById(customerId);
        if (c == null) throw new InvalidAccountException("Customer not found.");
        if (getAccountByNumber(accNumber) != null) throw new InvalidAccountException("Account number already exists.");
        BankAccount newAcc;
        if (type.equalsIgnoreCase("savings")) {
            newAcc = new SavingsAccount(accNumber, customerId, initialBalance, extra); // extra->minimumBalance
        } else if (type.equalsIgnoreCase("checking")) {
            newAcc = new CheckingAccount(accNumber, customerId, initialBalance, extra); // extra->overdraftLimit
        } else {
            throw new InvalidAccountException("Unknown account type.");
        }
        c.addAccount(newAcc);
        addAccount(newAcc);
    }
}
