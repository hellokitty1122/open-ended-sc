import java.util.Scanner;

/**
 * Entry point. Allows user to choose between Admin console and ATM.
 */
public class Main {
    public static void main(String[] args) {
        Bank bank = new Bank();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Bank System ---");
            System.out.println("1) ATM (Customer)");
            System.out.println("2) Admin");
            System.out.println("0) Exit");
            System.out.print("Choice: ");
            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1":
                    ATM atm = new ATM(bank);
                    atm.start();
                    break;
                case "2":
                    AdminInterface admin = new AdminInterface(bank);
                    admin.start();
                    break;
                case "0":
                    System.out.println("Goodbye.");
                    return;
                default:
                    System.out.println("Invalid selection.");
            }
        }
    }
}
