import java.util.List;
import java.util.Scanner;

/**
 * Customer-facing ATM CLI.
 * Supports intra-customer and cross-customer transfers.
 */
public class ATM {
    private final Bank bank;
    private final Scanner scanner = new Scanner(System.in);

    public ATM(Bank bank) { this.bank = bank; }

    public void start() {
        System.out.println("Welcome to CLI ATM");
        while (true) {
            System.out.println("\n1) Customer Login\n2) Exit to Main");
            System.out.print("Choice: ");
            String ch = scanner.nextLine().trim();
            switch (ch) {
                case "1": userLogin(); break;
                case "2": return;
                default: System.out.println("Invalid option.");
            }
        }
    }

    private void userLogin() {
        System.out.print("Enter Customer ID: ");
        String cid = scanner.nextLine().trim();
        Customer c = bank.getCustomerById(cid);
        if (c == null) { System.out.println("Customer not found."); return; }
        if (c.isAtmBlocked()) { System.out.println("ATM access blocked for this user. Contact admin."); return; }

        System.out.print("Enter PIN: ");
        String pin = scanner.nextLine().trim();
        if (!c.verifyPin(pin)) {
            System.out.println("Invalid PIN.");
            if (c.isAtmBlocked()) System.out.println("Too many attempts - ATM blocked.");
            return;
        }

        showAccountMenu(c);
    }

    private void showAccountMenu(Customer c) {
        while (true) {
            System.out.println("\nSelect account:");
            List<BankAccount> accs = c.getAccounts();
            for (int i = 0; i < accs.size(); i++) {
                System.out.printf("%d) %s (%.2f)%n", i+1, accs.get(i).getAccountNumber(), accs.get(i).getBalance());
            }
            System.out.println("0) Logout");
            System.out.print("Choice: ");
            String sel = scanner.nextLine().trim();
            int idx;
            try { idx = Integer.parseInt(sel); } catch (NumberFormatException ex) { System.out.println("Invalid input."); continue; }
            if (idx == 0) return;
            if (idx < 1 || idx > accs.size()) { System.out.println("Invalid selection"); continue; }
            BankAccount active = accs.get(idx - 1);
            accountOperations(c, active);
        }
    }

    private void accountOperations(Customer c, BankAccount acc) {
        while (true) {
            System.out.println("\nAccount: " + acc.getAccountNumber() + " | Balance: " + String.format("%.2f", acc.getBalance()));
            System.out.println("1) Check Balance  2) Deposit  3) Withdraw  4) View Transactions  5) Transfer Funds  6) Back");
            System.out.print("Choice: ");
            String ch = scanner.nextLine().trim();
            try {
                switch (ch) {
                    case "1": System.out.println("Balance: " + acc.getBalance()); break;
                    case "2": doDeposit(acc); break;
                    case "3": doWithdraw(acc); break;
                    case "4": viewTransactions(acc); break;
                    case "5": transferMenu(c, acc); break;
                    case "6": return;
                    default: System.out.println("Invalid option.");
                }
            } catch (Exception e) {
                System.out.println("Operation failed: " + e.getMessage());
            }
        }
    }

    private void doDeposit(BankAccount acc) throws AccountBlockedException {
        System.out.print("Enter amount to deposit: ");
        double amt = Double.parseDouble(scanner.nextLine().trim());
        acc.deposit(amt);
        System.out.println("Deposit successful. New balance: " + acc.getBalance());
    }

    private void doWithdraw(BankAccount acc) throws InsufficientFundsException, AccountBlockedException {
        System.out.print("Enter amount to withdraw: ");
        double amt = Double.parseDouble(scanner.nextLine().trim());
        acc.withdraw(amt);
        System.out.println("Withdrawal successful. New balance: " + acc.getBalance());
    }

    private void viewTransactions(BankAccount acc) {
        System.out.println("--- Transactions for " + acc.getAccountNumber() + " ---");
        if (acc.getTransactions().isEmpty()) System.out.println("No transactions yet.");
        for (Transaction t : acc.getTransactions()) System.out.println(t);
    }

    private void transferMenu(Customer c, BankAccount source) {
        System.out.println("1) Transfer between my accounts\n2) Transfer to another customer's account\n0) Cancel");
        System.out.print("Choice: ");
        String ch = scanner.nextLine().trim();
        switch (ch) {
            case "1": intraCustomerTransfer(c, source); break;
            case "2": crossCustomerTransfer(source); break;
            case "0": return;
            default: System.out.println("Invalid option.");
        }
    }

    private void intraCustomerTransfer(Customer c, BankAccount source) {
        List<BankAccount> accs = c.getAccounts();
        if (accs.size() < 2) { System.out.println("You need at least two accounts to perform internal transfer."); return; }
        System.out.println("Select destination account:");
        for (int i = 0; i < accs.size(); i++) {
            System.out.printf("%d) %s (%.2f)%n", i+1, accs.get(i).getAccountNumber(), accs.get(i).getBalance());
        }
        System.out.print("Choice: ");
        int choice = Integer.parseInt(scanner.nextLine().trim());
        if (choice < 1 || choice > accs.size()) { System.out.println("Invalid choice."); return; }
        BankAccount dest = accs.get(choice - 1);
        if (dest.getAccountNumber().equals(source.getAccountNumber())) { System.out.println("Source and destination are same."); return; }
        System.out.print("Enter amount to transfer: ");
        double amt = Double.parseDouble(scanner.nextLine().trim());
        try {
            source.transferTo(dest, amt);
            System.out.println("Transfer successful.");
            System.out.printf("New balances: %s: %.2f | %s: %.2f%n",
                    source.getAccountNumber(), source.getBalance(), dest.getAccountNumber(), dest.getBalance());
        } catch (Exception e) {
            System.out.println("Transfer failed: " + e.getMessage());
        }
    }

    private void crossCustomerTransfer(BankAccount source) {
        System.out.print("Enter destination account number: ");
        String destAccNo = scanner.nextLine().trim();
        BankAccount dest = bank.getAccountByNumber(destAccNo);
        if (dest == null) { System.out.println("Destination account not found."); return; }
        System.out.print("Enter amount to transfer: ");
        double amt = Double.parseDouble(scanner.nextLine().trim());
        try {
            source.transferTo(dest, amt);
            System.out.println("Transfer successful.");
            System.out.printf("%s new balance: %.2f%n", source.getAccountNumber(), source.getBalance());
        } catch (Exception e) {
            System.out.println("Transfer failed: " + e.getMessage());
        }
    }
}
