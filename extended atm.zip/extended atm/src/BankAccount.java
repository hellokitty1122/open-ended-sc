import java.util.ArrayList;

/**
 * Abstract bank account. Implements a transferTo helper that uses withdraw/deposit
 * to perform a transfer and create transactions on both accounts.
 */
public abstract class BankAccount {
    protected final String accountNumber;
    protected double balance;
    protected final String customerId;
    protected AccountStatus status;
    protected final ArrayList<Transaction> transactions = new ArrayList<>();

    public BankAccount(String accountNumber, String customerId, double initialBalance) {
        this.accountNumber = accountNumber;
        this.customerId = customerId;
        this.balance = initialBalance;
        this.status = AccountStatus.ACTIVE;
    }

    public String getAccountNumber() { return accountNumber; }
    public double getBalance() { return balance; }
    public String getCustomerId() { return customerId; }
    public AccountStatus getStatus() { return status; }
    public ArrayList<Transaction> getTransactions() { return transactions; }

    public abstract void deposit(double amount) throws AccountBlockedException;
    public abstract void withdraw(double amount) throws InsufficientFundsException, AccountBlockedException;

    protected void addTransaction(Transaction t) { transactions.add(t); }

    /**
     * Transfer 'amount' from this account (source) to target account.
     * Creates transactions for both accounts with appropriate statuses.
     */
    public void transferTo(BankAccount target, double amount) throws InsufficientFundsException, AccountBlockedException, InvalidAccountException {
        if (target == null) throw new InvalidAccountException("Target account does not exist.");
        if (this.accountNumber.equals(target.getAccountNumber()))
            throw new InvalidAccountException("Source and destination accounts must be different.");
        if (this.status != AccountStatus.ACTIVE)
            throw new AccountBlockedException("Source account is not active.");
        if (target.getStatus() != AccountStatus.ACTIVE)
            throw new AccountBlockedException("Target account is not active.");

        // Attempt withdrawal first (may throw InsufficientFundsException)
        try {
            this.withdraw(amount);
            // If withdraw succeeded, deposit into target
            try {
                target.deposit(amount);
                // Create explicit TRANSFER transactions (already deposit/withdraw add transactions)
                Transaction tSrc = new Transaction(TransactionType.TRANSFER, amount, this.accountNumber, target.getAccountNumber(), TransactionStatus.SUCCESS);
                Transaction tTgt = new Transaction(TransactionType.TRANSFER, amount, this.accountNumber, target.getAccountNumber(), TransactionStatus.SUCCESS);
                this.addTransaction(tSrc);
                target.addTransaction(tTgt);
            } catch (AccountBlockedException ae) {
                // rollback - credit back to source if deposit failed due to target blocked (unlikely because checked earlier)
                this.balance += amount;
                Transaction tFail = new Transaction(TransactionType.TRANSFER, amount, this.accountNumber, target.getAccountNumber(), TransactionStatus.FAILED_BLOCKED_ACCOUNT);
                this.addTransaction(tFail);
                throw ae;
            }
        } catch (InsufficientFundsException e) {
            // record failed transaction on source
            Transaction tFail = new Transaction(TransactionType.TRANSFER, amount, this.accountNumber, target.getAccountNumber(), TransactionStatus.FAILED_INSUFFICIENT_FUNDS);
            this.addTransaction(tFail);
            throw e;
        }
    }
}
