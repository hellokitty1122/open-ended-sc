import java.util.Scanner;

/**
 * Simple admin interface with hardcoded credentials:
 * username: admin, password: password
 */
public class AdminInterface {
    private final Bank bank;
    private final Scanner scanner = new Scanner(System.in);

    public AdminInterface(Bank bank) { this.bank = bank; }

    public void start() {
        System.out.print("Admin username: ");
        String user = scanner.nextLine();
        System.out.print("Admin password: ");
        String pass = scanner.nextLine();

        if (!user.equals("cat") || !pass.equals("meow")) {
            System.out.println("Invalid admin credentials.");
            return;
        }

        while (true) {
            System.out.println("\n--- Admin Menu ---");
            System.out.println("1) View All Customers");
            System.out.println("2) View All Accounts");
            System.out.println("3) Create New Account for Existing Customer");
            System.out.println("4) Unblock Customer (ATM)");
            System.out.println("0) Exit Admin");
            System.out.print("Choice: ");
            String ch = scanner.nextLine().trim();
            try {
                switch (ch) {
                    case "1": viewAllCustomers(); break;
                    case "2": viewAllAccounts(); break;
                    case "3": createNewAccount(); break;
                    case "4": unblockCustomer(); break;
                    case "0": return;
                    default: System.out.println("Invalid option.");
                }
            } catch (Exception e) {
                System.out.println("Operation failed: " + e.getMessage());
            }
        }
    }

    private void viewAllCustomers() {
        System.out.println("--- Customers ---");
        for (Customer c : bank.getAllCustomers()) {
            System.out.printf("%s : %s%n", c.getCustomerId(), c.getName());
            if (c.getAccounts().isEmpty()) System.out.println("   No accounts.");
            for (BankAccount a : c.getAccounts()) {
                System.out.printf("   - %s (%s) : Balance=%.2f%n", a.getAccountNumber(), a.getClass().getSimpleName(), a.getBalance());
            }
        }
    }

    private void viewAllAccounts() {
        System.out.println("--- All Accounts ---");
        for (BankAccount a : bank.getAllAccounts()) {
            System.out.printf("%s | %s | Customer: %s | Balance: %.2f | Status: %s%n",
                    a.getAccountNumber(), a.getClass().getSimpleName(), a.getCustomerId(), a.getBalance(), a.getStatus());
        }
    }

    private void createNewAccount() {
        System.out.print("Enter existing Customer ID: ");
        String cid = scanner.nextLine().trim();
        System.out.print("Enter new Account Number: ");
        String accNo = scanner.nextLine().trim();
        System.out.print("Account Type (savings/checking): ");
        String type = scanner.nextLine().trim();
        System.out.print("Initial Balance: ");
        double bal = Double.parseDouble(scanner.nextLine().trim());
        double extra = 0;
        if (type.equalsIgnoreCase("savings")) {
            System.out.print("Minimum Balance for savings: ");
            extra = Double.parseDouble(scanner.nextLine().trim());
        } else {
            System.out.print("Overdraft limit for checking: ");
            extra = Double.parseDouble(scanner.nextLine().trim());
        }
        try {
            bank.createAccountForCustomer(cid, accNo, type, bal, extra);
            System.out.println("Account created successfully.");
        } catch (InvalidAccountException e) {
            System.out.println("Failed to create account: " + e.getMessage());
        }
    }

    private void unblockCustomer() {
        System.out.print("Enter Customer ID to unblock: ");
        String cid = scanner.nextLine().trim();
        Customer c = bank.getCustomerById(cid);
        if (c == null) {
            System.out.println("Customer not found.");
            return;
        }
        c.unblockAtm();
        System.out.println("Customer unblocked.");
    }
}
