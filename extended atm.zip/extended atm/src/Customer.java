import java.util.ArrayList;

/**
 * Represents a bank customer.
 * Note: PIN stored in plaintext here for lab simplicity; in production use hashed PINs.
 */
public class Customer {
    private final String customerId;
    private final String name;
    private final String pin;
    private boolean atmBlocked = false;
    private int failedPinAttempts = 0;
    private final ArrayList<BankAccount> accounts = new ArrayList<>();

    public Customer(String customerId, String name, String pin) {
        this.customerId = customerId;
        this.name = name;
        this.pin = pin;
    }

    public String getCustomerId() { return customerId; }
    public String getName() { return name; }
    public boolean isAtmBlocked() { return atmBlocked; }
    public ArrayList<BankAccount> getAccounts() { return accounts; }

    public void addAccount(BankAccount a) { accounts.add(a); }

    public boolean verifyPin(String input) {
        if (atmBlocked) return false;
        if (pin.equals(input)) {
            failedPinAttempts = 0;
            return true;
        } else {
            failedPinAttempts++;
            if (failedPinAttempts >= 3) atmBlocked = true;
            return false;
        }
    }

    public void unblockAtm() { atmBlocked = false; failedPinAttempts = 0; }
}
