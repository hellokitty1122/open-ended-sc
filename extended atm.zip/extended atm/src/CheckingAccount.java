public class CheckingAccount extends BankAccount {
    private final double overdraftLimit;

    public CheckingAccount(String accountNumber, String customerId, double initialBalance, double overdraftLimit) {
        super(accountNumber, customerId, initialBalance);
        this.overdraftLimit = overdraftLimit;
    }

    @Override
    public void deposit(double amount) throws AccountBlockedException {
        if (status != AccountStatus.ACTIVE) throw new AccountBlockedException("Account not active");
        if (amount <= 0) return;
        balance += amount;
        addTransaction(new Transaction(TransactionType.DEPOSIT, amount, null, accountNumber, TransactionStatus.SUCCESS));
    }

    @Override
    public void withdraw(double amount) throws InsufficientFundsException, AccountBlockedException {
        if (status != AccountStatus.ACTIVE) throw new AccountBlockedException("Account not active");
        if (amount <= 0) return;
        if (balance - amount < -overdraftLimit) {
            addTransaction(new Transaction(TransactionType.WITHDRAWAL, amount, accountNumber, null, TransactionStatus.FAILED_INSUFFICIENT_FUNDS));
            throw new InsufficientFundsException("Exceeds overdraft limit");
        }
        balance -= amount;
        addTransaction(new Transaction(TransactionType.WITHDRAWAL, amount, accountNumber, null, TransactionStatus.SUCCESS));
    }
}
