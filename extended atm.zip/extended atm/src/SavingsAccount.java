public class SavingsAccount extends BankAccount {
    private final double minimumBalance;

    public SavingsAccount(String accountNumber, String customerId, double initialBalance, double minimumBalance) {
        super(accountNumber, customerId, initialBalance);
        this.minimumBalance = minimumBalance;
    }

    @Override
    public void deposit(double amount) throws AccountBlockedException {
        if (status != AccountStatus.ACTIVE) throw new AccountBlockedException("Account not active");
        if (amount <= 0) return;
        balance += amount;
        addTransaction(new Transaction(TransactionType.DEPOSIT, amount, null, accountNumber, TransactionStatus.SUCCESS));
    }

    @Override
    public void withdraw(double amount) throws InsufficientFundsException, AccountBlockedException {
        if (status != AccountStatus.ACTIVE) throw new AccountBlockedException("Account not active");
        if (amount <= 0) return;
        if (balance - amount < minimumBalance) {
            addTransaction(new Transaction(TransactionType.WITHDRAWAL, amount, accountNumber, null, TransactionStatus.FAILED_INSUFFICIENT_FUNDS));
            throw new InsufficientFundsException("Withdrawal would breach minimum balance");
        }
        balance -= amount;
        addTransaction(new Transaction(TransactionType.WITHDRAWAL, amount, accountNumber, null, TransactionStatus.SUCCESS));
    }
}
